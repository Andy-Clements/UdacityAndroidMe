package com.example.android.android_me.ui;


import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.example.android.android_me.R;
// After creating the fragment..
// COMPLETED (4) Create a new Activity named MainActivity and a corresponding layout file that displays a MasterListFragment
// Remember, to display a static fragment in a layout file, use the <fragment> tag
public class MainActivity extends AppCompatActivity {
    /**
     * {@inheritDoc}
     * <p>
     * Perform initialization of all fragments.
     *
     * @param savedInstanceState
     */
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
}
